//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by dlg_about.rc
//
#define IDD_ABOUT                       101
#define IDB_DELPHI                      102
#define IDC_TAB                         1001
#define IDC_CINEMA                      1002
#define IDC_VERSION                     1003
#define IDC_AUTHOR                      1004
#define IDC_EMAIL                       1005
#define IDC_WWW                         1006
#define IDC_AUTHOR4                     1007
#define IDC_WWW2                        1008
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
