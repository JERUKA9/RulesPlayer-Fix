=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

					CinemaPlayer
					wersja: 1.21
				       dn. 06.01.2002

				 Autor: Zbigniew Chwedoruk
			      e-mail: info@cinemaplayer.prv.pl
			        www: www.cinemaplayer.prv.pl

			    Program nale�y do kategorii FREEWARE

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-




I. Informacje og�lne
====================


1. Co to za program i do czego s�u�y:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 
CinemaPlayer to program do odtwarzania film�w z napisami. Podstawowe cechy po szybko��
dzia�ania, prostota obs�ugi i niskie (wzgl�dnie) wymagania sprz�towe.

Pocz�tkowo program mia� by� tylko "kr�likiem do�wiadczalnym", na kt�rym chcia�em sprawdzi�
kilka "technik programistycznych". Z czasem okaza�o si�, �e wyszed� z niego ca�kiem
przyjemny kawa�ek softu, wi�c postanowi�em Wam go pokaza�.

Wszelkie opinie, uwagi, propozycje, krytyki i pochwa�y ;) mile widziane. Piszcie na maila.

2. Wymagania:
~~~~~~~~~~~~~

Do poprawnej pracy program potrzebuje directx6 lub wy�szego. W przypadku directx6 wymagany
jest dodatkowo pakiet directmedia. Niekt�re filmy wymagaj� dodatkowych kodek�w.
Program jest przeznaczony dla Windows 9x/ME/NT/2000.




II. Co nowego:
==============

wersja 1.3

06.01.2002

Troch� to trwa�o, ale w ko�cu jest nowa wersja!

* dodano playlist�, dost�pna jest pod klawiszem F11,
  na pe�nym ekranie wystarczy przesun�� kursor myszy do prawej kraw�dzi ekranu:
  - opcje pozwalaj�ce na edycj� listy po klikn�ciu prawym klawiszem myszy na playli�cie
  - rozpoznawane formaty list:
    - PLS
    - M3U
    - ASX
    - VPL
    - BPP
    - LST
  - autopowtarzanie listy
  - odtwarzanie losowe
  - obs�uga Drag&Drop oraz lista film�w podana jako parametry uruchomieniowe
* dodano nowy format napis�w LRC (napisy do MP3)
* dodano "widok minimalny" (opr�cz filmu w oknie widoczny jest tylko prosty panel kontrolny)
* dodano menu do zmiany proporcji kadru (Widok->Powi�kszenie->Proporcje obrazu) lub 
  za pomoc� klawisza "przecinka" na klawiaturze numerycznej
* dodano opcja kasowania historii
* dodano skr�t do opcji zamykania systemu po sko�czonym odtwarzaniu Ctrl + F4
* pod Windows XP program wykorzystuje nowy wygl�d kontrolek
* troch� przebudowano uk�ad menu
* zmieniono skr�ty (kolidowa�y z playlist�) do regulacji g�o�no�ci (Home, End) 
  oraz du�ych skok�w (Ctrl + kursor w lewo, Ctrl + kursor w prawo)
* usuni�to opcj� zatrzymuj�c� odtwarzanie po wywo�aniu opcji lub menu kontekstowego
* po wczytaniu tekstu w czasie ogl�dania filmu obraz traci� proporcje
* po wyj�ciu z programu z pe�nego ekranu na pasku zada� pozostawa� "�lad" po aplikacji
* pojawia� si� b��d podczas zapisu konfiguracji do katalogu g��wnego (np. C:\)
* po przejsciu z/do pe�nego ekranu przez chwil� na napisach by�y widoczne �mieci
* �le dzia�a�o rozpoznawanie formatu kr�tkich plik�w z napisami (ok. 10 linii)
* inne drobne zmiany i poprawki



Wa�niejsze zmiany w kolejnych wersjach:
 - edytor napis�w
 - zrzuty obrazu do pliku (screenshot)
 - obs�uga AC3
 - czekam na Twoj� propozycj�...


III. Obs�uga programu
=====================


1. Oto co potrafi CinemaPlayer:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

* Wczytywanie filmu (lub pliku audio)	(Ctrl + O)
 - film mo�na wczyta� r�wnie� przez przeci�gni�cie z eksploratora i upuszczenie go na oknie
   programu.
 - automatyczne wczytywanie pliku z napisami, je�eli ma on tak� sam� nazw�, jak plik z
   filmem oraz znajduje si� w tym samym katalogu co film lub w domy�lnym katalogu
   dla napis�w.
 - program pami�ta 10 ostatnio otwartych film�w (pami�tane s� te� pliki z napisami do nich);
 - mo�na wczyta� film zapami�tany na zak�adce.
 - z klawiszem SHIFT otwarcie katalogu domy�lnego dla film�w

* Wczytywanie napis�w (Ctrl + T)
 - otwierany jest katalog z filmem lub katalog, w kt�rym znajduj� si� ostatnio wczytywane
   napisy.
 - z klawiszem SHIFT otwarcie katalogu domy�lnego dla napis�w
 - obs�uga nast�puj�cych format�w napis�w:
   - {xxxx}{xxxx}Jaki� tekst...
   - {xxxx}{}Jaki� tekst...
   - hh:mm:ss:Jaki� tekst...
   - hh:mm:ss=Jaki� tekst...
   - hh:mm:ss,x:Jaki� tekst...
   - xxxx,xxxx,x,Jakis tekst...
   - xxxx,xxxx,Jakis tekst...
   - [xxxx][xxxx]Jakis tekst|/Jaki� tekst...
   - hh:mm:ss --> hh:mm:ss
     Jaki� tekst1...
     Jaki� tekst2...

* Odtwarzanie/Pauza (Spacja)
 - w czasie odtwarzania filmu program blokuje wygaszacz ekranu

* Zatrzymanie (. /Kropka/)

* �atwe i szybkie przechodzenie do dowolnego fragmentu filmu. Program umo�liwia nawigacj�
  do przodu i do ty�u o:
 - obs�uga myszy ze scrollem
 - 1 sekund� (Enter/Backspace)
 - 10 sekund (Strza�ka w prawo/Strza�ka w lewo)
 - 1 minut�  (PgDown/PgUp)
 dwie ostatnie wielko�ci mo�na zmieni� w opcjach.

* Zmiana wielko�ci kadru
 - przesuwanie kadru w dowolnym kierunku (Num1 do Num9) lub za pomoc� myszy:
   chwycenie wewn�trznego obszaru kadru, pozwala przesuwa� kadr w pionie
   z klawiszem CTRL mo�na r�wnie� zmieni� po�o�enie w poziomie
 - powi�kszenie/pomniejszenie kadru (Num+/Num-) lub za pomoc� myszy:
   chwycenie za kraw�d� filmu i przeci�gni�cie w wybrane po�o�enie
 - przytrzymanie CTRL podczas przeci�gania mysz�, pozwala zmieni� proporcje kadru
   (za pomoc� klawiatury: CTRL + Num2,Num4,Num6,Num8).
 - dopasowanie kadru do okna programu (Num0) lub podw�jny klik
   podw�jny klik z wcisni�tym klawiszem CTRL rozci�ga kadr do wielko�ci okna i przywraca
   oryginalne proporcje kadru.
 - cykliczne naciskanie "kropki" na klawiaturze numerycznej powoduje rozci�ganie kadru na
   ca�e okno playera i powr�t do aktualnie ustawionych proporcji.
 - 50% wielko�ci filmu (Alt + 1)
 - 100% wielko�ci filmu (Alt + 2)
 - 200% wielko�ci filmu (Alt + 3)

* Zmiana tempa odtwarzania filmu
 - zmniejszenie tempa odtwarzania filmu (Ctrl + Z)
 - zwi�kszenie tempa odtwarzania filmu (Ctrl + C)
 - przywr�cenie normalnego tempa (Ctrl + X)

* Zmiana poziomu g�o�no�ci
 - g�o�niej (Strza�ka w g�r�)
 - ciszej (Strza�ka w d�)
 - wycisz (Ctrl + M)
 - obs�uga myszy ze scrollem

* Manipulacja napisami
 - przesuni�cie napis�w wzgl�dem filmu o sekund� do ty�u ([)
 - przesuni�cie napis�w wzgl�dem filmu o sekund� do przodu (])
 - anulowanie przesuni�� (P)			
 - ukrycie/pokazanie napis�w (Alt + T)
 - pomniejszenie czcionki (Ctrl + -)
 - powi�kszenie czcionki (Ctrl + =)
 - zmiana po�o�enia napis�w w pionie (Ctrl + strza�ka w g�r�/strza�ka w d�) lub za pomoc�
   myszy
 - na pasku statusu pokazywane jest o ile przesuni�te s� napisy wzgl�dem filmu

* Tryb pe�noekranowy
 - pe�ny ekran (Alt + Enter)
 - pe�ny ekran ze zmian� rozdzielczo�ci (Ctrl + Enter)
 - powr�t do okna (Esc)
 - po przesuni�ciu myszki na d� lub g�r� ekranu pokazuje si� panel kontrolny

* Parametry uruchomieniowe. Pozwalaj� na np. nagranie p�ytki z autorunem.
  Kolejno�� parametr�w jest nieistotna:
 - film ze �cie�k� dost�pu
 - napisy ze �cie�k� dost�pu
 - /f - start w trybie pe�noekranowym
 - /ff - start w trybie pe�noekranowym ze zmian� rozdzielczo�ci
 je�eli wyst�puj� spacje, to �cie�ki nale�y umie�ci� w cudzys�owach
 - /m - start w zmaksymalizowanym oknie

* Wieloj�zyczno�� programu
 - Wystarczy umie�ci� plik z przet�umaczonymi napisami w katalogu i program b�dzie
  obs�ugiwa� dany j�zyk. Pilki maj� rozszerzenie "lng", ale maj� struktur� plik�w "ini".
  J�zyk polski jest wbudowany w program. Plik 'Polski.lng' do��czony zosta� tam tylko
  w celu u�atwienia wykonywania t�umacze� osobom nieznaj�cym j�zyka angielskiego.

* Inne cechy
 - w czasie odtwarzania filmu blokowany jest wygaszacz ekranu
 - napisy s� wy�wietlane bezpo�rednio na filmie
 - automatycznie wykrywana jest ilo�� linii tekstu widocznych na ekranie



2. Opcje dost�pne z poziomu okienka "Options":
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Zak�adka "Napisy":
------------------------------

* Wyb�r czcionki i kolor�w dla napis�w
* Zmiana grubo�ci obw�dki wok� liter
* Skalowanie wysoko�ci czcionki w zale�no�ci od wielko�ci okienka. Je�eli opcja jest
  w��czona to wybrana wysoko�� czcionki dotyczy pe�nego ekranu
* Odleg�o�� napis�w od dolnej kraw�dzi filmu (w procentach wysoko�ci filmu)
* Czas przez jaki wy�wietlany jest napis (je�eli plik z napisami tego nie okre�la)
* Domy�lny folder dla napis�w. Tutaj program szuka pliku, je�eli nie znajdzie go w folderze,
  w kt�rym znajduje si� film

Zak�adka "Odtwarzanie":
------------------------------

* Nawigacja pozwala na przewijanie i szybki dost�p do dowolnego fragmentu filmu. Ma�e kroki
  s� te� u�ywane do przewijania filmu za pomoc� scrolla w myszce
* K�ko myszy mo�e sterowa� przeszukiwaniem filmu lub regulacj� g�o�no�ci
* Mo�na zmieni� odwr�ci� kierunek przwijania filmu scrollem myszy
* Czas po jakim zostanie ukryty kursor myszy w trybie pe�noekranowym
* Mo�na wybra� rozdzielczo�� jaka b�dzie u�yta w trybie pe�noekranowym ze zmian�
  rozdzielczo�ci
* Ukrywanie paska zada� w trybie pe�noekranowym - przydatne gdy pasek ma w��czon� opcj�
  'Autoukrywanie'
* Mo�na automatycznie przej�� do trybu pe�noekranowego w momencie rozpocz�cia odtwarzania
  (r�wnie� ze amian� rozdzielczo�ci)
* Na pe�nym ekranie mo�na przenie�� panel kontrolny na g�r� ekranu
* Liczba klatek na sekund� dla plik�w '.asf' i tekst�w w formacie z klatkami
* Mo�na automatyczne odtwarza� film po za�adowaniu
* Mo�na nakaza� zamkni�cie playera po sko�czeniu odtwarzania filmu
* Mo�na nakaza� uruchamianie tylko jedej kopii programu
* Mo�na zamkn��/u�pi� system po sko�czonym odtwarzaniu filmu
* Domy�lny folder dla film�w


Zak�adka "FileTypes"/"Typy plik�w":
-----------------------------------

Program mo�e s�u�y� jako domy�lny odtwarzacz film�w w systemie.
W oknie dialogowym wyboru pliku (wczytywanie filmu) wy�wietlane s� tylko te pliki, kt�rych
rozszerzenia wymienione s� na tej zak�adce.
* Lista znajduj�ca si� po lewej stronie zawiera pliki, kt�re nie s� skojarzone
  z odtwarzaczem, ale program mo�e je otwiera�. Pliki te mog� mie� dodan� opcj�
  "Open with CinemaPlayer" do menu kontekstowego.
* Lista po prawej stronie zawiera pliki, kt�re w eksploratorze maj� by� automatycznie
  otwierane za pomoc� CinemaPlayera.


IV. Troch� historii
===================

wersja 1.21

11.07.2001

Tym razem kolejne zmiany po bardzo kr�tkiej przerwie.

* dodano obs�ug� nowego formatu napisowego (SRT - SubRipper)
* uzupe�nonono obs�ug� formatu napisowego MPL2 (znacznik kursywy)
* k�ko w myszy mo�e s�u�y� do przeszukiwania filmu lub zmiany g�o�no�ci; dodatkowo gdy
  aktywna jest jedna z opcji, ustawienie kursora myszy nad kontrolk� s�u��c� do
  manipulowania drug� opcj�, pozwala sterowa� k�kiem myszy t� drug� opcj�
* dodano domy�lny katalog dla film�w. Katalog ten jest otwierany jako pocz�tkowy przy
  wczytywaniu pierwszego filmu po uruchomieniu programu; kolejne wywo�ania opcji
  "Otw�rz film" jako pocz�tkowego katalogu u�ywaj� tego, w kt�rym znajduje si� ostatnio
  otwarty film; klawisz SHIFT pozwala na u�ycie domy�lnego katalogu jako pocz�tkowego
  w dowolnym momencie
* program kontroluje swoje po�o�enie spowodowane zmian� rozmiar�w okna po otwarciu nowego
  filmu, je�eli spowoduje to cz�ciowe wysusi�cie okna poza ramy pulpitu, to player
  skoryguje odpowiednio swoje po�o�enie; zmiana rozmiar�w okna po otwoarciu filmu
  odbywa si� r�wnomiernie w ka�dym kierunku, a nie np. tylko w prawo i w d� (je�eli player
  znajdowa� si� dok�adnie na �rodku ekranu, to jest tak r�wniez po otwarciu filmu
* na pasku statusu pokazywane jest o ile przesuni�te s� napisy wzgl�dem filmu
  (klawisze "[", "]" oraz "P")
* okienko "Opcje" mo�na wywo�a� r�wnie� za pomoc� klawisza F12
* wprowadzono kilka kosmetycznych poprawek i usuni�to par� drobnych b��d�w zauwa�onych
  w wersji 1.2 przez u�ytkownik�w



wersja 1.2

02.07.2001

Po d�ugiej przerwie spora porcja nowo�ci. Pomimo du�ej ilo�ci zmian player zwi�kszy� swoj�
wielko�� tylko o 2KB!

* program nie korzysta ju� z MediaPlayera, dzi�ki czemu jest mniejszy, zajmuje kilka (3-5)
  MB RAMu mniej w por�wnaniu do innych player�w; zmala�o tak�e obci��enie procesora.
* zmiana wielko�ci, proporcji i po�o�enia kadru:
  - wystarczy chwyci� mysz� za kraw�d� filmu (zmieni si� kursor myszy) i przeci�gn��
    w wybrane po�o�enie, aby zmieni� wielko�� kadru (z zachowaniem proporcji obrazu).
  - przytrzymuj�c CTRL podczas powy�szej operacji, mo�na zmieni� proporcje kadru
    (lub za pomoc� klawiatury: CTRL + 2,4,6,8 numeryczne).
  - chwycenie mysz� wewn�trznego obszaru kadru, pozwala przesuwa� kadr w pionie.
    z klawiszem CTRL mo�na r�wnie� zmieni� po�o�enie w poziomie.
  - podw�jny klik rozci�ga kadr do wielko�ci okna (Num0, wcze�niej by�o Ctrl + Num5)
  - podw�jny klik z wcisni�tym klawiszem CTRL rozci�ga kadr do wielko�ci okna i przywraca
    oryginalne proporcje kadru.
  - cykliczne naciskanie "kropki" na klawiaturze numerycznej powoduje rozci�ganie kadru na
    ca�e okno playera i powr�t do aktualnie ustawionych proporcji.
* poprawiony algorytm analizuj�cy napisy z plik�w (odporniejszy na drobne b��dy w plikach)
* obs�uga nowych format�w napis�w:
 - MPL:
    0000,0000,0,Jakis tekst...
    0000,0000,Jakis tekst...
 - MPL2:
    [0000][0000]Jakis tekst...
    Ten format nie jest jeszcze w pe�ni obs�ugiwany (ignorowany jest atrybut pochy�o�ci)
* usunu�ty b��d "Cannot change Visible in OnShow or OnHide"
* natychmiastowe przej�cie do pe�nego ekranu (bez prze�adowania filmu)
* poprawnie dzia�a ukrywanie kursora na pe�nym ekranie
* zmiana po�o�enia napis�w za pomoc� myszy i klawiatury (Ctrl + "strza�ka w g�r�/d�")
* dost�p do w�a�ciwo�ci kodek�w
* mo�liwo�� wyboru cz�stotliwo�ci od�wierzania dla pe�nego ekranu w Windows NT/2000
* panel kontrolny na pe�nym ekranie mo�na przenie�� do g�ry (nie zas�ania napis�w)
* dodana opcja zmiany kierunku dzia�ania k�ka myszy
* historia (ostatnio otwierane pliki) zosta�a przeniesiona do podmenu. Takie samo podmenu
  pojawi�o si� w menu kontekstowym. Obecnie program pami�ta 10 film�w
* po najechaniu myszk� nad suwak pozwalaj�cy na przewijanie filmu w "dymku" pokazywany jest
  czas, jakiemu odpowiada po�o�enie kursora myszy.
* przyciski odpowiadaj�ce za zmian� pr�dko�ci odtwarzania filmu zosta�y usuni�te. W zamian
  pojawi� si� ma�y suwak nad regulacj� g�osno�ci.
* nowy parametr w linii polece� "/m" powoduje otwarcie playera w oknie,
  ale zmaksymalizowanym.
* zak�adki - mo�na zapami�ta� pozycj� odtwarzanego filmu i p�niej wczyta� film z zak�adki
* mo�liwo�� zapisania wi�kszo�ci ustawie� odtwarzacza do pliku. Przydatne przy nagrywaniu
  p�yt CD. Pozwala na dopasowanie odtwarzacza do konkretnego filmu.
  Zapami�tywane s� nast�puj�ce parametry:
    - autostart po za�adowaniu
    - zamknij po sko�czeniu
    - odleg�o�� napis�w od dolnej kraw�dzi
    - czcionka, kolor i rozmiar obw�dki
    - domy�lna warto�� FPS dla asf'�w
    - przewijanie filmu - ma�y i du�y krok
    - czas pokazywania napis�w
    - czas ukrycia kursora
    - g�o�no��
    - otwieranie jednej kopii programu
    - ukrywanie paska zada� na pe�nym ekranie
    - przej�cie do pe�nego ekranu po za�adowaniu
    - skalowanie napis�w w okienku
* poprawnie dzia�a wy��czanie wygaszania monitora podczas odtwarzania filmu
* w czasie wykonywania zmian w opcjach film jest pauzowany
* mo�liwo�� zamkni�cia/u�pienia systemu po sko�czonym odtwarzaniu
* na pasku statusu pokazywana jest aktualna pr�dko�� odtwarzania (fps)
* �rodkowy przycisk myszy dzia�a jak ENTER (przesuwa film o sekund� do przodu)
* oraz kilka drobnych b��d�w i niedoci�gni��, kt�rych nie spos�b wymieni�


wersja 1.1

24.02.2001

Pierwsze koty za p�oty! Oto kolejne udoskonalenia cinemaplayera:

* polska wersja! wystarczy umie�ci� plik z przet�umaczonymi napisami w katalogu i program
  b�dzie obs�ugiwa� dany j�zyk
* czasami program wy�wietla� tylko kawa�ek ostatniej litery w linii napisu
* podczas minimalizacji film jest pauzowany
* podczas minimalizacji programu w trybie pe�noekranowym ze zmian� rozdzielczo�ci nast�puje
  powr�t do normalnej rozdzielczo�ci
* je�eli w trybie pe�noekranowym ukrywany jest pasek zada�, to podczas minimalizacji
  programu jest on pokazywany
* szybsze zamykanie programu je�eli program jest w trybie pe�noekranowym
* poprawiona obs�uga parametr�w uruchomieniowych (autorun)


wersja 1.0

01.02.2001

Pe�na wersja, pozbawiona b��d�w. Chyba... :). Pierwsza publiczna edycja.

* poprawiona obs�uga scrolla myszy
* w menu kontekstowym opcja minimalizacji playera w trybie pe�noekranowym
* klikaj�c na aktualny czas filmu mo�na prze��cza� opcj� "Time remaining"
* mo�liwo�� wy��czenia skalowania napis�w
* teraz podczas minimalizacji zawsze widoczny jest pasek zada�
* kolejne drobne poprawki


wersja 0.9.9 beta

* opcja automatycznego przej�cia do trybu pe�noekranowego w momencie rozpocz�cia odtwarzania
  filmu
* parametry uruchomieniowe:
 - �cie�ka dostepu do filmu
 - �cie�ka dostepu do tekstu
 - /f - start w trybie pe�noekranowym
 - /ff - start w trybie pe�noekranowym ze zmian� rozdzielczo�ci
 kolejno�� parametr�w jest nieistotna
* jeszcze bardziej przyspieszony algorytm renderowania napis�w
* przewijanie filmu za pomoc� scrolla myszy
* kilka drobnych poprawek


wersja 0.9.8 beta

* czasami program zawiesza� si� przy wychodzeniu
* wyb�r rozdzielczo�ci dla trybu pe�noekranowego  w opcjach na WinNT/2000 nie dzia�a�
  poprawnie
* okienko statystyki
* troch� drobnych poprawek


wersja 0.9.7 beta

* czasami program zawiesza� si� po oko�o godzinie ogl�dania
* poprawiony i znacznie przyspieszony algorytm renderowania napis�w
* poprawione dzia�anie opcji "Open with CinemaPlayer"
* skalowanie napis�w w zale�no�ci od wielko�ci filmu (rozmiar podany w opcjach dotyczy
  pe�nego ekranu)
* opcja wy�wietlania czasu jaki pozosta� do ko�ca filmu


wersja 0.9.6 beta

* w ko�cu usuni�ty b��d powoduj�cy znikanie napis�w
* opcja uruchamiania tylko jednej kopii programu
* okienko wyboru pliku z filmem uwzgl�dnia rozszerzenia podane na zak�adce 'File types'
  w opcjach.
* opcja wyboru rozdzielczo�ci u�ywanej przy pe�nym ekranie (w trybie ze zmian�
  rozdzielczosci)
* domy�lna liczba klatek na sekund� dla pli�w '.asf' i napis�w w formacie z klatakami
  (microDVD)
* troch� drobnych poprawek


wersja 0.9.5 beta

* dodane kojarzenie plik�w z programem.
* dla plik�w nie skojarzonych mo�na doda� opcj� "Open with CinemaPlayer" do menu
  kontekstowego.
* szybka zmiana wielko�ci czcionki dla napis�w (Ctrl + -/=)
* troch� drobnych poprawek


wersja 0.9.2 beta

* opcja ukrywania menu start w czasie odtwarzania filmu na pe�nym ekranie
* domy�lny katalog z napisami. Program szuka pliku w katalogu z filmem, gdy nie znajdzie to
  szuka w katalogu z napisami. Je�eli podczas otwierania okienka dialogowego do wybierania
  plik�w z napisami b�dzie przytrzymany klawisz SHIFT to dialog otworzy si� z domy�lnym
  katalogiem napis�w (bez SHIFT otwiera si� katalog filmu lub ostatnio otwieranego pliku 
  z napisami).
* troch� drobnych poprawek



wersja 0.9.1 beta

* wy��czenie screensavera w czasie odtwarzania filmu
* pami�tanie plik�w z napisami w historii (5 ostatnich film�w)
* opcja "Stay on top"
* panel kontrolny na pe�nym ekranie po przesuni�ciu myszki na d� ekranu
* poprawione zamykanie programu po sko�czeniu odtworzenia filmu
* masa drobnych poprawek


wersja 0.9 beta

Pierwsza "doros�a" wersja programu. Na razie program posiada ma�o opcji i du�o b��d�w :)
* podstawowa rzecz, czyli odtwarzanie filmu i napis�w ju� dzia�a ;)
* czcionka ma sta�y rozmiar, szczerze m�wi�c(pisz�c) prawie wszystko jest na "sztywno"
* mo�na za�adowa� film przez przeci�gni�cie i upuszczenie go na oknie programu
* automatycznie wczytywane s� napisy o takiej samej nazwie jak film
* pami�tanych jest 5 ostatnio otwieranych film�w
* automatycznie wykrywana jest ilo�� linii tekstu widocznych na ekranie w danym momencie
* i troch� innych, lepiej lub gorzej dzia�aj�cych bajer�w...

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-


To wszystko...
Mi�ego ogl�dania!!!


(C) Zbigniew Chwedoruk
Bia�a Podlaska/Opole 2001