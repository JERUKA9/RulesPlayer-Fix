//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by dlgs.rc
//
#define IDD_SETTINGS                    2000
#define IDC_TREE                        2001
#define IDC_TITLE                       2002
#define IDC_APPLY                       2003
#define IDD_ABOUT                       3000
#define IDB_DELPHI                      3001
#define IDC_TAB                         3002
#define IDC_CINEMA                      3003
#define IDC_VERSION                     3004
#define IDC_AUTHOR                      3005
#define IDC_EMAIL                       3006
#define IDC_WWW                         3007
#define IDC_AUTHOR4                     3008
#define IDC_WWW2                        3009
#define IDC_LIST                        3010
#define IDD_SBT_FONT                    4000
#define IDC_LB_EXAMPLE                  4001
#define IDC_ED_FONT_NAME                4002
#define IDC_LB_FONT_NAME                4003
#define IDC_LB_FONT_SIZE                4004
#define IDC_ED_FONT_SIZE                4005
#define IDC_BT_CHANGE_FONT              4006
#define IDC_LB_RENDER                   4007
#define IDC_CBO_RENDER                  4008
#define IDC_LB_ANTIALIAS                4009
#define IDC_CBO_ANTIALIAS               4010
#define IDC_CHK_OVERLAY                 4011
#define IDC_GRP_COLORS                  4012
#define IDC_LB_TEXTCOLOR                4013
#define IDC_LB_BKGCOLOR                 4014
#define IDC_BT_DEFCOLORS                4015
#define IDC_SHP_TEXTCOLOR               4016
#define IDC_SHP_BKGCOLOR                4017
#define IDD_SBT_OTHER                   5000
#define IDC_GRP_OTHERFONT               5001
#define IDC_CHK_AUTOSIZE                5002
#define IDC_LB_EDGE                     5003
#define IDC_LB_EDGE2                    5004
#define IDC_IED_EDGE                    5005
#define IDC_LB_SUBROWS                  5006
#define IDC_IED_SUBROWS                 5007
#define IDC_CHK_AUTOTIME                5008
#define IDC_LB_CALCTIME                 5009
#define IDC_IED_CALCTIME                5010
#define IDC_LB_CALCTIME2                5011
#define IDC_GRP_SBTFOLDER               5012
#define IDC_ED_SBTFOLDER                5013
#define IDC_BT_SBTFOLDER                5014
#define IDD_PLAY_NAVI                   6000
#define IDC_LB_LARGESTEPS               6001
#define IDC_IED_LARGESTEPS              6002
#define IDC_LB_SMALLSTEPS               6003
#define IDC_IED_SMALLSTEPS              6004
#define IDC_GRP_MOUSEWHEEL              6005
#define IDC_RD_WHEELPOSITION            6006
#define IDC_RD_WHEELVOLUME              6007
#define IDC_CHK_REVERSEWHEEL            6008
#define IDD_PLAY_FULLSCR                7000
#define IDC_LB_HIDECURSOR               7001
#define IDC_IED_HIDECURSOR              7002
#define IDC_LB_HIDECURSOR2              7003
#define IDC_CHK_HIDETASKBAR             7004
#define IDC_CHK_AUTOFULLSCREEN          7005
#define IDC_CHK_CHANGERESOLUTION        7006
#define IDC_CBO_RESOLUTION              7007
#define IDC_CBO_FREQUENCY               7008
#define IDC_CHK_PANELONTOP              7009
#define IDC_CHK_PAUSEONCONTROL          7010
#define IDD_PLAY_OTHER                  8000
#define IDC_LB_ASFFPS                   8001
#define IDC_CBO_ASFFPS                  8002
#define IDC_CHK_AUTOPLAY                8003
#define IDC_CHK_CLOSEPLAYER             8004
#define IDC_CHK_ONEINSTANCE             8005
#define IDC_CHK_SEARCHNEXTPART          8006
#define IDC_GRP_CLOSESYSTEM             8007
#define IDC_CHK_REMEMBERSUSPENDSTATE    8008
#define IDC_RD_SUSPENDSYSTEM            8009
#define IDC_RD_SHUTDOWNSYSTEM           8010
#define IDC_CHK_SHUTDOWNDELAY           8011
#define IDC_IED_SHUTDOWNDELAY           8012
#define IDC_LB_SHUTDOWNDELAY            8013
#define IDC_GRP_MOVIEFOLDER             8014
#define IDC_ED_MOVIEFOLDER              8015
#define IDC_BT_MOVIEFOLDER              8016
#define IDD_EDITOR                      9000
#define IDC_CHK_STOPONERROR             9001
#define IDD_FILES                       11000
#define IDC_GRP_FILESSUPPORTED          11001
#define IDC_LB_FILESNOTASSOCIATED       11002
#define IDC_LB_FILESASSOCIATED          11003
#define IDC_BT_INCLUDE                  11004
#define IDC_BT_INCALL                   11005
#define IDC_BT_EXCLUDE                  11006
#define IDC_BT_EXCALL                   11007
#define IDC_ED_ADDEXT                   11008
#define IDC_BT_ADDEXT                   11009
#define IDC_CHK_ADDTOCONTEXT            11010
#define IDC_BT_APPLYCHANGES             11011

#define IDC_STATIC                      -1

#include "windows.h"
// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         90001
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
